import { Pool } from "pg";
import type { IncomingMessage, ServerResponse } from "node:http";
const normalizeDatabaseUrl = (value) => {
  const raw = String(value || "").replace(/[?&]sslmode=[^&]+/i, "");
  if (!raw) return raw;
  try {
    const url = new URL(raw);
    const match = url.hostname.match(/^db\.([a-z0-9]+)\.supabase\.co$/i);
    if (!match) return raw;
    const projectRef = match[1];
    const region = String(process.env.SUPABASE_DB_REGION || "us-west-2").trim();
    const poolerHost = String(process.env.SUPABASE_POOLER_HOST || `aws-0-${region}.pooler.supabase.com`).trim();
    url.hostname = poolerHost;
    url.port = "6543";
    if (url.username === "postgres") url.username = `postgres.${projectRef}`;
    return url.toString();
  } catch {
    return raw;
  }
};

const dbUrl=normalizeDatabaseUrl(process.env.DATABASE_URL||"");
const db=dbUrl?new Pool({connectionString:dbUrl,max:3,ssl:{rejectUnauthorized:false}}):null;
const MASTER=process.env.MASTER_API_TOKEN||"", BILLING=process.env.BILLING_API_TOKEN||"";
const json=(res:ServerResponse,status:number,value:unknown)=>{res.statusCode=status;res.setHeader("content-type","application/json; charset=utf-8");res.setHeader("cache-control","no-store");res.end(JSON.stringify(value));};
const bearer=(req:IncomingMessage)=>String(req.headers.authorization||"").replace(/^Bearer\s+/i,"").trim();
const role=(req:IncomingMessage)=>{const t=bearer(req);if(t&&t===MASTER)return "master";if(t&&t===BILLING)return "billing";return null};
const body=(req:IncomingMessage)=>new Promise<unknown>((resolve,reject)=>{const c:Buffer[]=[];req.on("data",x=>c.push(Buffer.from(x)));req.on("end",()=>{try{resolve(c.length?JSON.parse(Buffer.concat(c).toString("utf8")):{});}catch{reject(new Error("Request body must be valid JSON"));}});req.on("error",reject);});
const allowedKeys=["title","description","changelog","customer_notes","internal_notes","severity","required","rollout","minimum_version","rollback_version","components","permissions","compatibility","schema_version"];
export default async function releaseControl(req:IncomingMessage,res:ServerResponse):Promise<void>{try{if(!role(req))return json(res,401,{error:"Unauthorized"});if(!db)return json(res,503,{error:"Database is not configured"});const id=String(new URL(req.url||"/","http://localhost").searchParams.get("id")||"");if(!id)return json(res,400,{error:"Release id is required"});if(req.method!=="PATCH"&&req.method!=="POST")return json(res,405,{error:"Method not allowed"});const input:Record<string,unknown>=await body(req);const set:string[]=[];const values:unknown[]=[id];for(const k of allowedKeys){if(!(k in input))continue;let v:unknown=input[k];if(k==="rollout"){const rolloutValue=String(v).toLowerCase();if(!["internal","beta","public"].includes(rolloutValue))return json(res,400,{error:"rollout must be internal, beta, or public"});v=rolloutValue;}if(k==="severity"){const severityValue=String(v).toLowerCase();if(!["normal","important","critical"].includes(severityValue))return json(res,400,{error:"severity must be normal, important, or critical"});v=severityValue;}values.push(v);set.push(`${k}=$${values.length}`);}if(!set.length)return json(res,400,{error:"No release fields supplied"});set.push("updated_at=now()");const q=`update releases set ${set.join(",")} where id=$1 returning *`;const result=await db.query(q,values);if(!result.rows[0])return json(res,404,{error:"Release not found"});return json(res,200,{ok:true,release:result.rows[0]});}catch(e:unknown){return json(res,500,{error:e instanceof Error?e.message:String(e)})}}
