import { Pool } from "pg";
import type { IncomingMessage, ServerResponse } from "node:http";

const normalizeDatabaseUrl = (value) => {
  const raw = String(value || "").replace(/[?&]sslmode=[^&]+/i, "");
  if (!raw) return raw;
  try {
    const url = new URL(raw);
    const match = url.hostname.match(/^db\.([a-z0-9]+)\.supabase\.co$/i);
    if (!match) return raw;
    const projectRef = match[1];
    const region = String(process.env.SUPABASE_DB_REGION || "us-west-2").trim();
    const poolerHost = String(process.env.SUPABASE_POOLER_HOST || `aws-0-${region}.pooler.supabase.com`).trim();
    url.hostname = poolerHost;
    url.port = "6543";
    if (url.username === "postgres") url.username = `postgres.${projectRef}`;
    return url.toString();
  } catch {
    return raw;
  }
};

const dbUrl=normalizeDatabaseUrl(process.env.DATABASE_URL||"");
const db=dbUrl?new Pool({connectionString:dbUrl,max:3,ssl:{rejectUnauthorized:false}}):null;
const MASTER=process.env.MASTER_API_TOKEN||"", BILLING=process.env.BILLING_API_TOKEN||"", DEPLOYER=process.env.DEPLOYER_API_TOKEN||"";
const GITHUB_TOKEN=process.env.GITHUB_TOKEN||process.env.GH_TOKEN||"";
const json=(res:ServerResponse,status:number,value:unknown)=>{res.statusCode=status;res.setHeader("content-type","application/json; charset=utf-8");res.setHeader("cache-control","no-store");res.end(JSON.stringify(value));};
const bearer=(req:IncomingMessage)=>String(req.headers.authorization||"").replace(/^Bearer\s+/i,"").trim();
const role=(req:IncomingMessage)=>{const t=bearer(req);if(t&&t===MASTER)return "master";if(t&&t===BILLING)return "billing";if(t&&t===DEPLOYER)return "deployer";return null};
const body=(req:IncomingMessage):Promise<Record<string,unknown>>=>new Promise<Record<string,unknown>>((resolve,reject)=>{const c:Buffer[]=[];req.on("data",x=>c.push(Buffer.from(x)));req.on("end",()=>{try{const value=c.length?JSON.parse(Buffer.concat(c).toString("utf8")):{};if(!value||typeof value!=="object"||Array.isArray(value))throw new Error("object required");resolve(value as Record<string,unknown>);}catch{reject(new Error("Request body must be valid JSON"));}});req.on("error",reject);});
async function source(repo:string,branch:string){if(!GITHUB_TOKEN)throw new Error("GITHUB_TOKEN is not configured");const r=await fetch(`https://api.github.com/repos/${repo}/commits?sha=${encodeURIComponent(branch)}&per_page=1`,{headers:{accept:"application/vnd.github+json",authorization:`Bearer ${GITHUB_TOKEN}`,"x-github-api-version":"2022-11-28","user-agent":"OrbitFS-License-Master-V2"}});const d=await r.json().catch(()=>[]);if(!r.ok)throw new Error(String(d?.message||"GitHub source lookup failed"));const c=Array.isArray(d)?d[0]:null;if(!c?.sha)throw new Error(`No commits found for ${repo} / ${branch}`);return {repo,branch,sha:String(c.sha),shortSha:String(c.sha).slice(0,12),message:String(c.commit?.message||"").split("\n")[0],date:c.commit?.author?.date||c.commit?.committer?.date||null,url:c.html_url||`https://github.com/${repo}/commit/${c.sha}`};}
export default async function releaseCapture(req:IncomingMessage,res:ServerResponse){try{const r=role(req);if(!r||!(["master","billing"].includes(r)))return json(res,401,{error:"Unauthorized"});if(req.method!=="POST")return json(res,405,{error:"Method not allowed"});if(!db)return json(res,503,{error:"Database is not configured"});const input=await body(req);const kind=String(input.kind||"update").toLowerCase()==="base"?"base":"update";const component=kind==="base"?"orbitfs_base":"orbitfs_mcp";const repo=kind==="base"?"lucaskerim123/V1-vercel-base":"lucaskerim123/V1-vercel-engine";const branch=kind==="base"?"base-release":"release-updates";const s=await source(repo,branch);const version=String(input.version||s.sha.slice(0,12));const channel=kind;const id=`rel_${component}_${version.replace(/[^a-zA-Z0-9_.-]/g,"-")}`;const manifest={sourceRepo:repo,sourceBranch:branch,sourceCommit:s.sha,sourceUrl:s.url,sourceMessage:s.message,sourceDate:s.date,captureKind:kind,packageFormat:kind==="base"?"orbitfs-panel-release-v1":"orbitfs-engine-release-v1"};const result=await db.query("insert into releases(id,component,version,channel,status,title,description,changelog,customer_notes,internal_notes,severity,required,rollout,schema_version,components,manifest,permissions,compatibility,source_commit) values($1,$2,$3,$4,'draft',$5,$6,$7,'','', 'normal',false,'internal','1',$8,$9,'{}','{}',$10) on conflict(component,channel,version) do update set source_commit=excluded.source_commit,manifest=excluded.manifest,updated_at=now() returning *",[id,component,version,channel,String(input.title||`${component} ${version}`),String(input.description||`Captured from ${repo} / ${branch}`),String(input.changelog||s.message),JSON.stringify(kind==="base"?["orbitfs_base"]:["orbitfs_mcp"]),JSON.stringify(manifest),s.sha]);return json(res,200,{ok:true,release:result.rows[0],source:s});}catch(e:unknown){return json(res,500,{error:e instanceof Error?e.message:String(e)})}}
