import type { IncomingMessage, ServerResponse } from "node:http";
import { Pool } from "pg";

const normalizeDatabaseUrl = (value) => {
  const raw = String(value || "").replace(/[?&]sslmode=[^&]+/i, "");
  if (!raw) return raw;
  try {
    const url = new URL(raw);
    const match = url.hostname.match(/^db\.([a-z0-9]+)\.supabase\.co$/i);
    if (!match) return raw;
    const projectRef = match[1];
    const region = String(process.env.SUPABASE_DB_REGION || "us-west-2").trim();
    const poolerHost = String(process.env.SUPABASE_POOLER_HOST || `aws-0-${region}.pooler.supabase.com`).trim();
    url.hostname = poolerHost;
    url.port = "6543";
    if (url.username === "postgres") url.username = `postgres.${projectRef}`;
    return url.toString();
  } catch {
    return raw;
  }
};

const DATABASE_URL = normalizeDatabaseUrl(process.env.DATABASE_URL || "");
const db = DATABASE_URL ? new Pool({ connectionString: DATABASE_URL, max: 3, ssl: { rejectUnauthorized: false } }) : null;
const SUPABASE_URL = String(process.env.SUPABASE_URL || "").replace(/\/$/, "");
const SERVICE = process.env.SUPABASE_SERVICE_ROLE_KEY || "";
const MASTER = process.env.MASTER_API_TOKEN || "";
const ADMIN_EMAILS = new Set((process.env.ADMIN_EMAILS || "").split(",").map((x) => x.trim().toLowerCase()).filter(Boolean));
const json = (res: ServerResponse, status: number, value: unknown) => { res.statusCode = status; res.setHeader("content-type", "application/json; charset=utf-8"); res.setHeader("cache-control", "no-store"); res.end(JSON.stringify(value)); };
const token = (req: IncomingMessage) => String(req.headers.authorization || "").replace(/^Bearer\s+/i, "").trim();
async function admin(req: IncomingMessage) { const t = token(req); if (!t) return false; if (MASTER && t === MASTER) return true; if (!SUPABASE_URL || !SERVICE) return false; const r = await fetch(`${SUPABASE_URL}/auth/v1/user`, { headers: { apikey: SERVICE, authorization: `Bearer ${t}` } }); if (!r.ok) return false; const u = await r.json() as { email?: string; app_metadata?: { role?: string } }; return ADMIN_EMAILS.has(String(u.email || "").toLowerCase()) || u.app_metadata?.role === "admin"; }
async function ensureSettingsTable() { if (!db) throw new Error("Database is not configured"); await db.query(`create table if not exists master_license_settings (id text primary key, issuer text not null default 'orbitfs-license-master', audience text not null default 'orbitfs-runtime', entitlement_ttl_seconds integer not null default 10800, grace_seconds integer not null default 604800, revision bigint not null default 1, updated_at timestamptz not null default now()); alter table master_license_settings add column if not exists api_mode text not null default 'online'; alter table master_license_settings add column if not exists allow_offline_grace boolean not null default true; insert into master_license_settings(id) values ('primary') on conflict (id) do nothing;`); }
async function settings(method: string, input: Record<string, unknown> = {}) { await ensureSettingsTable(); if (method === "GET") { const row = (await db!.query("select id,issuer,audience,entitlement_ttl_seconds,grace_seconds,api_mode,allow_offline_grace,revision,updated_at from master_license_settings where id='primary'")).rows[0]; if (!row) throw new Error("License Master settings row is unavailable"); return row; } const current = (await db!.query("select * from master_license_settings where id='primary'")).rows[0] || {}; const mode = String(input.api_mode ?? input.mode ?? current.api_mode ?? "online").toLowerCase(); if (!["online","offline","maintenance"].includes(mode)) throw new Error("api_mode must be online, offline, or maintenance"); const row = (await db!.query(`update master_license_settings set issuer=$1,audience=$2,entitlement_ttl_seconds=$3,grace_seconds=$4,api_mode=$5,allow_offline_grace=$6,revision=$7,updated_at=now() where id='primary' returning id,issuer,audience,entitlement_ttl_seconds,grace_seconds,api_mode,allow_offline_grace,revision,updated_at`, [String(input.issuer ?? current.issuer ?? "orbitfs-license-master"), String(input.audience ?? current.audience ?? "orbitfs-runtime"), Math.max(60, Math.floor(Number(input.entitlement_ttl_seconds ?? current.entitlement_ttl_seconds ?? 10800))), Math.max(0, Math.floor(Number(input.grace_seconds ?? current.grace_seconds ?? 604800))), mode, input.allow_offline_grace === undefined ? current.allow_offline_grace !== false : Boolean(input.allow_offline_grace), Math.max(1, Math.floor(Number(input.revision ?? Number(current.revision || 0) + 1)))])).rows[0]; return row; }
async function readBody(req: IncomingMessage) { const chunks: Buffer[] = []; for await (const c of req) chunks.push(Buffer.isBuffer(c) ? c : Buffer.from(c)); if (!chunks.length) return {}; const value = JSON.parse(Buffer.concat(chunks).toString("utf8")); if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("Request body must be an object"); return value as Record<string, unknown>; }
export default async function handler(req: IncomingMessage, res: ServerResponse) { if (req.method === "OPTIONS") { res.statusCode = 204; return res.end(); } if (!(await admin(req))) return json(res, 401, { error: "Administrator authentication is required" }); try { if (req.method === "GET") { const s = await settings("GET"); return json(res, 200, { ok: true, settings: s, database: true, settings_found: true }); } if (req.method !== "PATCH" && req.method !== "POST") return json(res, 405, { error: "Method not allowed" }); const s = await settings(req.method, await readBody(req)); return json(res, 200, { ok: true, settings: s, database: true, settings_found: true }); } catch (e) { return json(res, 503, { ok: false, database: false, settings_found: false, error: e instanceof Error ? e.message : "License Master settings operation failed" }); } }
